### R code from vignette source 'pareto.Rnw'

###################################################
### code chunk number 1: pareto.Rnw:13-16
###################################################
library(ggplot2)
library(pareto)
library(xtable)


###################################################
### code chunk number 2: pareto.Rnw:29-34
###################################################
dpareto(2, 1, 1)
ppareto(2, 1, 1)
qpareto(0.5, 1, 1)
rpareto(1, 1, 1)
rcpareto(1, 1, 1)


###################################################
### code chunk number 3: pareto.Rnw:38-41
###################################################
dpareto(2, 1, 1, TRUE)
ppareto(2, 1, 1, TRUE)
qpareto(0.5, 1, 1, TRUE)


###################################################
### code chunk number 4: pareto.Rnw:50-55
###################################################
dpareto(1:3, 1:2, 1:2)
ppareto(1:4, 1, 1)
qpareto(seq(0.1, 0.9, 0.2), 1, 1)
rpareto(5, 1:2, 1:3)
rcpareto(5, 1:2, 1:3)


###################################################
### code chunk number 5: pareto.Rnw:60-66
###################################################
m <- cbind(1:10, dpareto(1:10, 1, 1), 
           ppareto(1:10, 1, 1))
colnames(m)<-c("x", "dpareto(x)", "ppareto(x)")
xtable(as.data.frame(m),align=rep("c",4),
       caption=paste("The density and cdf of the Pareto(1, 1) distribution"),
       label="tab:pareto")


###################################################
### code chunk number 6: pareto.Rnw:73-81
###################################################
x <- seq(0, 20, 0.001)
example <- data.frame(x = rep(x, 2),
                      y = c(dpareto(x, 1, 1), ppareto(x, 1, 1)),
                      fun = factor(c(rep("dpareto", length(x)), 
                                     rep("ppareto", length(x)))))
ggplot(example) + geom_line(aes(x = x, y = y, color = fun)) + 
  scale_x_continuous("X") + scale_y_continuous("Density") + 
  theme_bw()


###################################################
### code chunk number 7: pareto.Rnw:108-111
###################################################
p.dpareto(1:3, 1:2, 1:2, P = 2)
p.ppareto(1:4, 1, 1, P = 2)
p.qpareto(seq(0.1, 0.9, 0.2), 1, 1, P = 2)


